package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class Login  extends JFrame implements ActionListener{
    
    JButton Login ,clear ,signup;
    JTextField cardTextField;
    JPasswordField pinTextField;
    
    Login(){
        setTitle("Customer Login");
        
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/9721949.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(70, 10, 100, 100);
        add(label);
        
        JLabel text = new JLabel("Welcome to Our CITY Bank");

        text.setFont(new Font("Osward", Font.BOLD, 38));
        text.setBounds(200, 40, 500, 40);
        text.setForeground(Color.BLACK);
        add(text);
        
        JLabel CARD_NO = new JLabel("CARD NO  :");
        CARD_NO.setFont(new Font("Raleway", Font.BOLD, 26));
        CARD_NO.setBounds(119, 150, 500, 50);
        CARD_NO.setForeground(Color.BLACK);
        add(CARD_NO);
        
        cardTextField = new JTextField();
        cardTextField.setBounds(285, 155, 300, 45);
        cardTextField.setFont (new Font("Arial", Font.BOLD,20));
        add(cardTextField);
        
        JLabel PIN_CODE = new JLabel("PIN NO      :");
        PIN_CODE.setFont(new Font("Raleway", Font.BOLD, 26));
        PIN_CODE.setBounds(120, 230, 500, 50);
        PIN_CODE.setForeground(Color.BLACK);
        add(PIN_CODE);
        
        pinTextField = new JPasswordField();
        pinTextField.setBounds(285, 237, 300, 45);
        pinTextField.setFont (new Font("Arial", Font.BOLD,20));
        add(pinTextField);
        
        Login = new JButton("Sign in");
        Login.setBounds(290, 320, 120, 40);
        Login.setBackground(Color.white);
        Login.setForeground(Color.BLACK);
        Login.addActionListener(this);
        add(Login);
        
        clear = new JButton("Clear");
        clear.setBounds(460, 320, 120, 40);
        clear.setBackground(Color.white);
        clear.setForeground(Color.BLACK);
        clear.addActionListener(this);
        add(clear);
        
        signup = new JButton("Create Account");
        signup.setBounds(340, 380, 200, 40);
        signup.setBackground(Color.white);
        signup.setForeground(Color.BLACK);
        signup.addActionListener(this);
        add(signup);
        
        
        getContentPane().setBackground(Color.LIGHT_GRAY);
        
    setSize(800, 480);
    setVisible(true);
    setLocation(600,300);
    
    }
    
    
    public void actionPerformed(ActionEvent ae){
    
    if (ae.getSource() == clear){
        cardTextField.setText("");
        pinTextField.setText("");
    
    }else if (ae.getSource() == Login){
    Connect c = new Connect();
    String cardnumber = cardTextField.getText();
    String pinnumber = pinTextField.getText();
    String query = "select * from login where cardnumber = '"+cardnumber+"' and pin = '"+pinnumber+"'";
    try {
        ResultSet rs = c.s.executeQuery(query);
        if (rs.next()){
            setVisible(false);
            new Transaction(pinnumber).setVisible(true);
        }else{
            JOptionPane.showMessageDialog(null,"Incorrect Card Number or Pin");
        }
    }catch (Exception e) {
        System.out.println(e);
    }
    }else if (ae.getSource() == signup){
    setVisible(false);
    new SignupONE().setVisible(true);
    }
        
    }
    
    public static void main(String args[]){
        new Login();
        
    }

    
    
}
