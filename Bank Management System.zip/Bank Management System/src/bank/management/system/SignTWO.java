package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SignTWO extends JFrame implements ActionListener{
    
    
    JTextField   pan;
    JButton next;
    JRadioButton syes, sno, eyes, eno;
    JComboBox religion, bloodgroup, Income, education, occupation;
    String formno;
    
    SignTWO(String formno){
        this.formno = formno;
        setLayout(null);
        
        setTitle("ACCOUNT APPLICATION FORM - PAGE 2");
        
        
        JLabel accountDetails = new JLabel("Page 2: Account Details");
        accountDetails.setFont(new Font("Raleway", Font.BOLD,22));
        accountDetails.setBounds(290, 80, 500, 30);
        add(accountDetails);
        
        JLabel name = new JLabel("Religion:");
        name.setFont(new Font("Raleway", Font.BOLD,20));
        name.setBounds(100, 180, 100, 30);
        add(name);
        
        String value_Religion[] = {"Muslim","Hindu","Boddoh","Christan"};
        religion = new JComboBox(value_Religion);
        religion.setBounds(300, 184, 400, 30);
        religion.setBackground(Color.white);
        add(religion);
        
         
  
        JLabel fname = new JLabel("Blood Group:");
        fname.setFont(new Font("Raleway", Font.BOLD,20));
        fname.setBounds(100, 240, 200, 30);
        add(fname);
        
        String value_bloodgroup[] = {"A+","B+","AB+","AB-","A-","O+","O-","B-"};
        bloodgroup = new JComboBox(value_bloodgroup);
        bloodgroup.setBounds(300, 244, 400, 30);
        bloodgroup.setBackground(Color.white);
        add(bloodgroup);
        
        
         
        
        JLabel dob = new JLabel("Income:");
        dob.setFont(new Font("Raleway", Font.BOLD,20));
        dob.setBounds(100, 290, 200, 30);
        add(dob);
        
        String value_Income[] = {"Null","<50","<100","<150","<200","upto 1000"};
        Income = new JComboBox(value_Income);
        Income.setBounds(300, 295, 400, 30);
        Income.setBackground(Color.white);
        add(Income);
        
        
        JLabel gender = new JLabel("Educational");
        gender.setFont(new Font("Raleway", Font.BOLD,20));
        gender.setBounds(100, 345, 200, 30);
        add(gender);
        
        JLabel email = new JLabel("Qualification:");
        email.setFont(new Font("Raleway", Font.BOLD,20));
        email.setBounds(100, 370, 200, 30);
        add(email);
        
        String value_educational[] = {"Non Graduate","graduate","Master's","Doctorate"};
        education = new JComboBox(value_educational);
        education.setBounds(300, 360, 400, 30);
        education.setBackground(Color.white);
        add(education);
        
        
        JLabel marital = new JLabel("Occupation:");
        marital.setFont(new Font("Raleway", Font.BOLD,20));
        marital.setBounds(100, 425, 200, 30);
        add(marital);
        
        String value_occupation[] = {"Part_Time Job","Business Man","Student","Retired"};
        occupation = new JComboBox(value_occupation);
        occupation.setBounds(300, 430, 400, 30);
        occupation.setBackground(Color.white);
        add(occupation);
       
        
        JLabel address = new JLabel("PAN:");
        address.setFont(new Font("Raleway", Font.BOLD,20));
        address.setBounds(100, 490, 200, 30);
        add(address);
        
        pan = new JTextField();
        pan.setFont(new Font("Raleway", Font.BOLD,14));
        pan.setBounds(300, 494, 400, 30);
        add(pan);
        
        JLabel city = new JLabel("Senior Citizen:");
        city.setFont(new Font("Raleway", Font.BOLD,20));
        city.setBounds(100, 540, 200, 30);
        add(city);
        
        syes = new JRadioButton("Yes");
        syes.setBounds(300,538,60,40);
        syes.setBackground(Color.WHITE);
        add(syes);
        
        sno = new JRadioButton("NO");
        sno.setBounds(450,538,80,40 );
        sno.setBackground(Color.WHITE);
        add(sno);
        
        ButtonGroup gendergroup = new ButtonGroup();
        gendergroup.add(syes);
        gendergroup.add(sno);
        
        
        JLabel pincode = new JLabel("Existing Account:");
        pincode.setFont(new Font("Raleway", Font.BOLD,20));
        pincode.setBounds(100, 590, 200, 30);
        add(pincode);
        
        eyes = new JRadioButton("Yes");
        eyes.setBounds(300,588,60,40);
        eyes.setBackground(Color.WHITE);
        add(eyes);
        
        eno = new JRadioButton("NO");
        eno.setBounds(450,588,80,40 );
        eno.setBackground(Color.WHITE);
        add(eno);
        
        ButtonGroup Account = new ButtonGroup();
        Account.add(eyes);
        Account.add(eno);
        
         
         next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(620, 660, 100, 40);
        next.addActionListener(this);
        add(next);
        
        
        getContentPane().setBackground(Color.WHITE);
        
setSize(850,800);
setLocation(600,150);
setVisible(true);
}
    
    
    public void actionPerformed(ActionEvent ae){
    
    String sreligion =(String) religion.getSelectedItem();
    String  sbloodgroup =(String) bloodgroup.getSelectedItem();
    String sIncome = (String) Income.getSelectedItem();
    String seducation = (String) education.getSelectedItem();
    String soccupation = (String) occupation.getSelectedItem();
    String seniorcitizen = null;
    if(syes.isSelected()){
    seniorcitizen = "Yes";
    } else if(sno.isSelected()){
    seniorcitizen = "No";
    }
    
    
    String existingaccount = null;
    if(eyes.isSelected()){
    existingaccount = "Yes";
    } else if(eno.isSelected()){
    existingaccount = "NO";
    } 
    
    String span = pan.getText();
    
    
    try{
    Connect c = new Connect();
    String query = "Insert into SignupTWO values('"+formno+"','"+sreligion+"','"+sbloodgroup+"','"+sIncome+"','"+seducation+"','"+soccupation+"','"+span+"','"+seniorcitizen+"','"+existingaccount+"')";
    c.s.executeUpdate(query);
  
    setVisible(false);
    new SignThree(formno).setVisible(true);
    
    }
    catch (Exception e){
    System.out.println(e);
    }
    }
    
   
    public static void main(String args[]){
    
        new SignTWO("");
        
    }

    
}