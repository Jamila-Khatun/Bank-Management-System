package bank.management.system;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class FastCash extends JFrame implements ActionListener{
    
    JButton deposit, withdrawl, fastcash, ministatement, pinchange, balanceenquiry, exit;
    String pinnumber;
    FastCash(String pinnumber){
        this.pinnumber = pinnumber;
        setLayout(null);
    
    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm-machine-isolated-on-white-background-free-vector.jpg"));
    Image i2 = i1.getImage().getScaledInstance(600, 800, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 600, 800);
        add(image);
        
        JLabel text = new JLabel("Select Withdrawl Amount");
        text.setBounds(190, 240, 700, 35);
        text.setForeground(Color.BLACK);
        text.setFont(new Font("System", Font.BOLD, 16));
        image.add(text);
        
         deposit = new JButton("TK 100");
        deposit.setBounds(130, 300, 130, 30);
        deposit.setBackground(Color.BLACK);
        deposit.setForeground(Color.WHITE);
        deposit.addActionListener(this);
        image.add(deposit);
        
         withdrawl = new JButton("TK 500");
        withdrawl.setBounds(340, 300, 130, 30);
        withdrawl.setBackground(Color.BLACK);
        withdrawl.setForeground(Color.WHITE);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
         fastcash = new JButton("TK 1000");
        fastcash.setBounds(130, 345, 130, 30);
        fastcash.setBackground(Color.BLACK);
        fastcash.setForeground(Color.WHITE);
        fastcash.addActionListener(this);
        image.add(fastcash);
        
         ministatement = new JButton("TK 2000");
        ministatement.setBounds(340, 345, 130, 30);
        ministatement.setBackground(Color.BLACK);
        ministatement.setForeground(Color.WHITE);
        ministatement.addActionListener(this);
        image.add(ministatement);
        
         pinchange = new JButton("TK 5000");
        pinchange.setBounds(130, 390, 130, 30);
        pinchange.setBackground(Color.BLACK);
        pinchange.setForeground(Color.WHITE);
        pinchange.addActionListener(this);
        image.add(pinchange);
        
         balanceenquiry = new JButton("TK 10000");
        balanceenquiry.setBounds(340, 390, 130, 30);
        balanceenquiry.setBackground(Color.BLACK);
        balanceenquiry.setForeground(Color.WHITE);
        balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);
        
         exit = new JButton("Back");
        exit.setBounds(230, 430, 130, 30);
        exit.setBackground(Color.BLACK);
        exit.setForeground(Color.WHITE);
        exit.addActionListener(this);
        image.add(exit);
        
        setSize(600, 800);
        setLocation(700,150);
        setUndecorated(true);
        setVisible(true);
    }

    FastCash() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()== exit){
            setVisible(false);
            new Transaction(pinnumber).setVisible(true);
        } else  {
            String amount = ((JButton)ae.getSource()).getText().substring(3); // tk 500
            Connect c = new Connect();
            try{
                ResultSet tk = c.s.executeQuery("select * from bank where pin = '"+pinnumber+"'");
            int balance = 0;
            while(tk.next()){
                if (tk.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(tk.getString("amount"));
                } else {
                    balance -= Integer.parseInt(tk.getString("amount"));
                    
                }
            }
            
            if (ae.getSource() != exit && balance < Integer.parseInt(amount)) {
                JOptionPane.showMessageDialog(null, "Insuffient Balance");
                return;
            }
            
            Date date = new Date();
            String query = "insert into bank values('"+pinnumber+"', '"+date+"', 'Withdrawl', '"+amount+"')";
            c.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "TK  "+amount+" Debited Sucessfully");
            
            setVisible(false);
            new Transaction(pinnumber).setVisible(true);
            } catch (Exception e) {
                System.out.println(e);
            }
        } 
    }
    
    public static void main(String args[]){
        
         new FastCash("");
    }
}
