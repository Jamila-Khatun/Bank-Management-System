
package bank.management.system;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;


public class BalanceEnquiry extends JFrame implements ActionListener{
    
    JButton back;
    String pinnumber;
    
    BalanceEnquiry(String pinnumber) {
        this.pinnumber = pinnumber;
        setLayout(null);
    
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm-machine-isolated-on-white-background-free-vector.jpg"));
        Image i2 = i1.getImage().getScaledInstance(600, 800, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 600, 800);
        add(image);
        
        back = new JButton("back");
        back.setBounds(335, 430, 150, 25);
        back.addActionListener(this);
        image.add(back);
        
        Connect c = new Connect();
        int balance = 0;
            try{
                ResultSet tk = c.s.executeQuery("select * from bank where pin = '"+pinnumber+"'");
            
            while(tk.next()){
                if (tk.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(tk.getString("amount"));
                } else {
                    balance -= Integer.parseInt(tk.getString("amount"));
                    
                }
            }
            }catch (Exception e) {
                    System.out.println(e);
                    }
            JLabel text = new JLabel("Your Current Account balance is TK " + balance);
            text.setForeground(Color.BLACK);
            text.setBounds(170, 300, 400, 30);
            image.add(text);
        
        setSize(600, 800);
        setLocation(700,150);
        setUndecorated(true);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Transaction(pinnumber).setVisible(true);
    }
    
public static void main(String args[]) {
new BalanceEnquiry("");
}

}